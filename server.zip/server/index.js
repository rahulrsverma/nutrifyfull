import express from 'express';
import bodyParser from 'body-parser';
import mongoose from 'mongoose';
import cors from 'cors';

// import routers
import healthDetailRouter from './routes/healthDetail.js';
import userRouter from './routes/user.js';
import dietRouter from './routes/diet.js';

const app = express();

app.use(bodyParser.json({ extended: true }));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(cors());

// HD Router
app.use('/HD', healthDetailRouter);
// user Router
app.use('/user', userRouter);
// diet Router
app.use('/diet', dietRouter);

// connect to mongoDB
const CONNECTION_URL = 'mongodb+srv://rahul:rahul@123@cluster0.3wogq.mongodb.net/myDb?retryWrites=true&w=majority';
const PORT = process.env.PORT || 4000;

mongoose.connect(CONNECTION_URL, { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => app.listen(PORT, () => console.log(`Server running on PORT: ${PORT}`)))
    .catch((error) => console.log(error.message));

mongoose.set('useFindAndModify', false);